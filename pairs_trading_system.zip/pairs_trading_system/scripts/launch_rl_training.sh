
#!/usr/bin/env bash
# Example SLURM submission or local launch
python -m src.rl.train_agent
